import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'

import { authOptions } from '@/lib/auth'
import { getSeatSnapshot } from '@/lib/seat-service'

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session || !session.user) {
    return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const snapshot = await getSeatSnapshot()
    return NextResponse.json({ success: true, data: snapshot })
  } catch (error) {
    console.error('[SEATS_GET]', error)
    return NextResponse.json({ success: false, error: 'Failed to load seat availability' }, { status: 500 })
  }
}
