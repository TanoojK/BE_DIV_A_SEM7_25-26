import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { z } from 'zod'
import type { Prisma } from '@prisma/client'
import { UserRole } from '@/types'

import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

const normalizeRole = (role?: string | null) => {
  if (!role) return null
  return String(role).trim().toUpperCase()
}

const OBJECT_ID_REGEX = /^[a-f\d]{24}$/i

type SessionUserLike = {
  id?: string | null
  role?: string | null
  studentId?: string | null
  email?: string | null
  department?: string | null
}

type ResolvedSessionUser = {
  id: string | null
  role: string | null
  department: string | null
}

const resolveSessionUser = async (sessionUser: SessionUserLike): Promise<ResolvedSessionUser> => {
  const normalizedRole = normalizeRole(sessionUser?.role)
  const sanitizedId = sessionUser?.id?.trim() ?? null
  const fallbackId = sanitizedId && OBJECT_ID_REGEX.test(sanitizedId) ? sanitizedId : null
  const fallbackDepartment = sessionUser?.department ?? null

  const orClauses: Prisma.UserWhereInput[] = []

  if (fallbackId) {
    orClauses.push({ id: fallbackId })
  }

  if (sessionUser?.studentId) {
    orClauses.push({ studentId: sessionUser.studentId })
  }

  if (sessionUser?.email) {
    orClauses.push({ email: sessionUser.email.toLowerCase() })
  }

  if (!orClauses.length) {
    return {
      id: fallbackId,
      role: normalizedRole,
      department: fallbackDepartment,
    }
  }

  try {
    const dbUser = await prisma.user.findFirst({
      where: { OR: orClauses },
      select: { id: true, role: true, department: true },
    })

    return {
      id: dbUser?.id ?? fallbackId,
      role: normalizeRole(dbUser?.role) ?? normalizedRole,
      department: (dbUser?.department as string | null | undefined) ?? fallbackDepartment,
    }
  } catch (error) {
    console.error('Failed to resolve session user identity', error)
    return {
      id: fallbackId,
      role: normalizedRole,
      department: fallbackDepartment,
    }
  }
}

const isAdminRole = (role?: string | null): role is UserRole.ADMIN | UserRole.LIBRARIAN => {
  const normalized = normalizeRole(role)
  if (!normalized) return false
  return normalized === UserRole.ADMIN || normalized === UserRole.LIBRARIAN
}

const isStudentRole = (role?: string | null): role is UserRole.STUDENT => {
  return normalizeRole(role) === UserRole.STUDENT
}

const updateSchema = z.object({
  action: z.enum(['mark-read', 'mark-unread', 'archive', 'restore']).default('mark-read'),
})

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } },
) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const { id: resolvedUserId, role: resolvedRole } = await resolveSessionUser(session.user)

  if (!resolvedUserId) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const broadcastId = params.id

  let payload: unknown

  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ message: 'Invalid JSON payload' }, { status: 400 })
  }

  const parsed = updateSchema.safeParse(payload)

  if (!parsed.success) {
    return NextResponse.json({
      message: 'Validation failed',
      errors: parsed.error.flatten(),
    }, { status: 422 })
  }

  const action = parsed.data.action

  try {
    if (action === 'mark-read') {
      if (!isStudentRole(resolvedRole)) {
        return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
      }

      const receipt = await prisma.broadcastReceipt.findUnique({
        where: {
          broadcastId_userId: {
            broadcastId,
            userId: resolvedUserId,
          },
        },
        select: {
          id: true,
          readAt: true,
        },
      })

      if (!receipt) {
        return NextResponse.json({ message: 'Broadcast not found' }, { status: 404 })
      }

      if (receipt.readAt) {
        return NextResponse.json({ message: 'Broadcast already read' }, { status: 200 })
      }

      await prisma.$transaction([
        prisma.broadcastReceipt.update({
          where: { id: receipt.id },
          data: { readAt: new Date() },
        }),
        prisma.broadcast.update({
          where: { id: broadcastId },
          data: {
            readCount: { increment: 1 },
          },
        }),
      ])

      return NextResponse.json({ message: 'Broadcast marked as read' })
    }

    if (action === 'mark-unread') {
      if (!isStudentRole(resolvedRole)) {
        return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
      }

      const receipt = await prisma.broadcastReceipt.findUnique({
        where: {
          broadcastId_userId: {
            broadcastId,
            userId: resolvedUserId,
          },
        },
        select: {
          id: true,
          readAt: true,
        },
      })

      if (!receipt) {
        return NextResponse.json({ message: 'Broadcast not found' }, { status: 404 })
      }

      if (!receipt.readAt) {
        return NextResponse.json({ message: 'Broadcast already unread' }, { status: 200 })
      }

      await prisma.$transaction([
        prisma.broadcastReceipt.update({
          where: { id: receipt.id },
          data: { readAt: null },
        }),
        prisma.broadcast.update({
          where: { id: broadcastId },
          data: {
            readCount: {
              decrement: 1,
            },
          },
        }),
      ])

      return NextResponse.json({ message: 'Broadcast marked as unread' })
    }

    if (action === 'archive') {
      if (!isAdminRole(resolvedRole)) {
        return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
      }

      await prisma.broadcast.update({
        where: { id: broadcastId },
        data: {
          isActive: false,
        },
      })

      return NextResponse.json({ message: 'Broadcast archived successfully' })
    }

    if (action === 'restore') {
      if (!isAdminRole(resolvedRole)) {
        return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
      }

      await prisma.broadcast.update({
        where: { id: broadcastId },
        data: {
          isActive: true,
          status: 'SENT',
        },
      })

      return NextResponse.json({ message: 'Broadcast restored successfully' })
    }

    return NextResponse.json({ message: 'Unsupported action' }, { status: 400 })
  } catch (error) {
    console.error('Failed to update broadcast', error)
    return NextResponse.json({ message: 'Failed to update broadcast' }, { status: 500 })
  }
}
