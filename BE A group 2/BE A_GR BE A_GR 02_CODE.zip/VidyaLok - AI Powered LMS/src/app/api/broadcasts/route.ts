import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { z } from 'zod'
import type { Prisma } from '@prisma/client'

import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import {
  UserAccountStatus,
  UserRole,
  type BroadcastTypeValue,
} from '@/types'

type BroadcastReceiptWhereInput = Prisma.BroadcastReceiptWhereInput
type BroadcastCreateInput = Parameters<typeof prisma.broadcast.create>[0]['data']
type AudienceFilterValue = BroadcastCreateInput extends { audienceFilter?: infer V }
  ? V
  : BroadcastCreateInput extends { audienceFilter: infer V }
    ? V
    : null

const normalizeRole = (role?: string | null) => {
  if (!role) return null
  return String(role).trim().toUpperCase()
}

const OBJECT_ID_REGEX = /^[a-f\d]{24}$/i

type SessionUserLike = {
  id?: string | null
  role?: string | null
  studentId?: string | null
  email?: string | null
  department?: string | null
}

type ResolvedSessionUser = {
  id: string | null
  role: string | null
  department: string | null
}

const resolveSessionUser = async (sessionUser: SessionUserLike): Promise<ResolvedSessionUser> => {
  const normalizedRole = normalizeRole(sessionUser?.role)
  const sanitizedId = sessionUser?.id?.trim() ?? null
  const fallbackId = sanitizedId && OBJECT_ID_REGEX.test(sanitizedId) ? sanitizedId : null
  const fallbackDepartment = sessionUser?.department ?? null

  const orClauses: Prisma.UserWhereInput[] = []

  if (fallbackId) {
    orClauses.push({ id: fallbackId })
  }

  if (sessionUser?.studentId) {
    orClauses.push({ studentId: sessionUser.studentId })
  }

  if (sessionUser?.email) {
    orClauses.push({ email: sessionUser.email.toLowerCase() })
  }

  if (!orClauses.length) {
    return {
      id: fallbackId,
      role: normalizedRole,
      department: fallbackDepartment,
    }
  }

  try {
    const dbUser = await prisma.user.findFirst({
      where: { OR: orClauses },
      select: { id: true, role: true, department: true },
    })

    return {
      id: dbUser?.id ?? fallbackId,
      role: normalizeRole(dbUser?.role) ?? normalizedRole,
      department: (dbUser?.department as string | null | undefined) ?? fallbackDepartment,
    }
  } catch (error) {
    console.error('Failed to resolve session user identity', error)
    return {
      id: fallbackId,
      role: normalizedRole,
      department: fallbackDepartment,
    }
  }
}

const broadcastTypeEnum = z.enum(['ANNOUNCEMENT', 'ALERT', 'MAINTENANCE', 'EVENT', 'EMERGENCY'] as const)
const broadcastPriorityEnum = z.enum(['NORMAL', 'HIGH', 'URGENT'] as const)
const broadcastAudienceEnum = z.enum(['ALL', 'DEPARTMENT', 'ROLE', 'CUSTOM'] as const)

const isAdminRole = (role?: string | null): role is UserRole.ADMIN | UserRole.LIBRARIAN => {
  const normalized = normalizeRole(role)
  if (!normalized) return false
  return normalized === UserRole.ADMIN || normalized === UserRole.LIBRARIAN
}

const isStudentRole = (role?: string | null): role is UserRole.STUDENT => {
  return normalizeRole(role) === UserRole.STUDENT
}

const createBroadcastSchema = z.object({
  title: z.string().min(5).max(140),
  message: z.string().min(10).max(2000),
  type: broadcastTypeEnum.default('ANNOUNCEMENT'),
  priority: broadcastPriorityEnum.default('NORMAL'),
  audience: broadcastAudienceEnum.default('ALL'),
  audienceFilter: z.record(z.unknown()).optional(),
  targetUserIds: z.array(z.string()).optional(),
  expiresAt: z.string().datetime().optional(),
  scheduleAt: z.string().datetime().optional(),
})

const mapBroadcastTypeToBadge = (type: BroadcastTypeValue) => {
  switch (type) {
    case 'ALERT':
      return { kind: 'alert', label: 'Alert' }
    case 'MAINTENANCE':
      return { kind: 'maintenance', label: 'Maintenance' }
    case 'EVENT':
      return { kind: 'event', label: 'Event' }
    case 'EMERGENCY':
      return { kind: 'emergency', label: 'Emergency' }
    default:
      return { kind: 'info', label: 'Announcement' }
  }
}

const toIsoString = (value?: Date | null) => (value ? value.toISOString() : null)

const extractAudienceFilterValue = (filter: unknown, key: string): string | null => {
  if (!filter || typeof filter !== 'object') {
    return null
  }

  const value = (filter as Record<string, unknown>)[key]
  if (typeof value !== 'string') {
    return null
  }

  return value.trim()
}

const shouldDeliverBroadcastToStudent = (
  broadcast: {
    id: string
    audience: string
    audienceFilter: unknown
    targetUserIds: string[]
  },
  context: {
    userId: string
    role: string | null
    department: string | null
  },
) => {
  switch (broadcast.audience) {
    case 'ALL':
      return true
    case 'ROLE': {
      const targetRole = normalizeRole(extractAudienceFilterValue(broadcast.audienceFilter, 'role'))
      return !!targetRole && targetRole === normalizeRole(context.role)
    }
    case 'DEPARTMENT': {
      const targetDepartment = extractAudienceFilterValue(broadcast.audienceFilter, 'department')
      if (!targetDepartment || !context.department) {
        return false
      }
      return targetDepartment.trim().toLowerCase() === context.department.trim().toLowerCase()
    }
    case 'CUSTOM': {
      return Array.isArray(broadcast.targetUserIds) && broadcast.targetUserIds.includes(context.userId)
    }
    default:
      return false
  }
}

const ensureStudentBroadcastReceipts = async (params: {
  userId: string
  role: string | null
  department: string | null
}) => {
  const { userId, role, department } = params

  if (!isStudentRole(role)) {
    return
  }

  const now = new Date()
  const candidateBroadcasts = await prisma.broadcast.findMany({
    where: {
      status: 'SENT',
      isActive: true,
      OR: [
        { expiresAt: null },
        { expiresAt: { gt: now } },
      ],
      receipts: {
        none: {
          userId,
        },
      },
    },
    select: {
      id: true,
      audience: true,
      audienceFilter: true,
      targetUserIds: true,
    },
  })

  if (!candidateBroadcasts.length) {
    return
  }

  const eligibleBroadcasts = candidateBroadcasts.filter((broadcast) =>
    shouldDeliverBroadcastToStudent(broadcast, { userId, role, department }),
  )

  if (!eligibleBroadcasts.length) {
    return
  }

  const affectedBroadcastIds = Array.from(new Set(eligibleBroadcasts.map((broadcast) => broadcast.id)))

  await prisma.$transaction(async (tx) => {
    await Promise.all(
      eligibleBroadcasts.map((broadcast) =>
        tx.broadcastReceipt.upsert({
          where: {
            broadcastId_userId: {
              broadcastId: broadcast.id,
              userId,
            },
          },
          update: {},
          create: {
            broadcastId: broadcast.id,
            userId,
          },
        }),
      ),
    )

    for (const broadcastId of affectedBroadcastIds) {
      const deliveredCount = await tx.broadcastReceipt.count({ where: { broadcastId } })
      await tx.broadcast.update({
        where: { id: broadcastId },
        data: {
          deliveredCount,
        },
      })
    }
  })
}

export async function GET(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const {
    id: resolvedUserId,
    role: sessionRole,
    department: resolvedDepartment,
  } = await resolveSessionUser(session.user)
  const isAdminSession = isAdminRole(sessionRole)

  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get('page') ?? '1', 10)
  const limit = Math.min(Number.parseInt(searchParams.get('limit') ?? '20', 10), 50)
  const summaryOnly = searchParams.get('summary') === 'true'
  const viewParam = searchParams.get('view')?.toLowerCase()
  const resolvedView = viewParam === 'admin' || viewParam === 'student'
    ? viewParam
    : isAdminSession
      ? 'admin'
      : 'student'

  if (resolvedView === 'student' && !isStudentRole(sessionRole)) {
    return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
  }

  if (resolvedView === 'admin' && !isAdminSession) {
    return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
  }

  try {
    if (resolvedView === 'admin') {
      const whereClause = {}
      const skip = Math.max(page - 1, 0) * limit

      const [broadcasts, total, sentToday, scheduledCount] = await Promise.all([
        prisma.broadcast.findMany({
          where: whereClause,
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
          include: {
            createdBy: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        }),
        prisma.broadcast.count({ where: whereClause }),
        prisma.broadcast.count({
          where: {
            status: 'SENT',
            sentAt: {
              gte: new Date(new Date().setHours(0, 0, 0, 0)),
            },
          },
        }),
        prisma.broadcast.count({
          where: {
            status: 'SCHEDULED',
          },
        }),
      ])

      const aggregatedReadRate = broadcasts.reduce(
        (acc, broadcast) => {
          if (broadcast.deliveredCount === 0) return acc
          return acc + broadcast.readCount / broadcast.deliveredCount
        },
        0,
      )
      const averageReadRate = broadcasts.length
        ? Math.round((aggregatedReadRate / broadcasts.length) * 100)
        : 0

      const data = broadcasts.map((broadcast) => ({
        id: broadcast.id,
        title: broadcast.title,
        message: broadcast.message,
        type: broadcast.type,
        priority: broadcast.priority,
        status: broadcast.status,
        isActive: broadcast.isActive,
        audience: broadcast.audience,
        audienceFilter: broadcast.audienceFilter,
        deliveredCount: broadcast.deliveredCount,
        readCount: broadcast.readCount,
        readRate: broadcast.deliveredCount === 0
          ? 0
          : Math.round((broadcast.readCount / broadcast.deliveredCount) * 100),
        createdAt: broadcast.createdAt.toISOString(),
        updatedAt: broadcast.updatedAt.toISOString(),
        sentAt: toIsoString(broadcast.sentAt),
        expiresAt: toIsoString(broadcast.expiresAt),
        scheduleAt: toIsoString(broadcast.scheduleAt),
        createdBy: broadcast.createdBy,
        badge: mapBroadcastTypeToBadge(broadcast.type),
      }))

      return NextResponse.json({
        data,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.max(Math.ceil(total / limit), 1),
        },
        summary: {
          totalBroadcasts: total,
          sentToday,
          scheduledCount,
          averageReadRate,
        },
      })
    }

    // Student view
    if (!resolvedUserId) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const studentDepartment = resolvedDepartment ?? (session.user.department as string | null | undefined) ?? null

    await ensureStudentBroadcastReceipts({
      userId: resolvedUserId,
      role: sessionRole,
      department: studentDepartment,
    })

    const baseWhere: BroadcastReceiptWhereInput = {
      userId: resolvedUserId,
      broadcast: {
        status: 'SENT',
        isActive: true,
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } },
        ],
      },
    }

    if (summaryOnly) {
      const unreadCount = await prisma.broadcastReceipt.count({
        where: {
          ...baseWhere,
          readAt: null,
        },
      })

      return NextResponse.json({
        data: [],
        summary: {
          unreadCount,
        },
      })
    }

    const skip = Math.max(page - 1, 0) * limit
    const [receipts, total, unreadCount] = await Promise.all([
      prisma.broadcastReceipt.findMany({
        where: baseWhere,
        orderBy: [
          { readAt: 'asc' },
          { deliveredAt: 'desc' },
        ],
        skip,
        take: limit,
        include: {
          broadcast: {
            select: {
              id: true,
              title: true,
              message: true,
              type: true,
              priority: true,
              sentAt: true,
              createdAt: true,
              expiresAt: true,
              audience: true,
            },
          },
        },
      }),
      prisma.broadcastReceipt.count({ where: baseWhere }),
      prisma.broadcastReceipt.count({
        where: {
          ...baseWhere,
          readAt: null,
        },
      }),
    ])

    const data = receipts.map((receipt) => ({
      id: receipt.broadcast.id,
      title: receipt.broadcast.title,
      message: receipt.broadcast.message,
      type: receipt.broadcast.type,
      priority: receipt.broadcast.priority,
      audience: receipt.broadcast.audience,
      sentAt: toIsoString(receipt.broadcast.sentAt ?? receipt.broadcast.createdAt),
      expiresAt: toIsoString(receipt.broadcast.expiresAt),
      deliveredAt: receipt.deliveredAt.toISOString(),
      readAt: toIsoString(receipt.readAt),
      unread: !receipt.readAt,
      badge: mapBroadcastTypeToBadge(receipt.broadcast.type),
    }))

    return NextResponse.json({
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.max(Math.ceil(total / limit), 1),
      },
      summary: {
        unreadCount,
      },
    })
  } catch (_error) {
    console.error('Failed to fetch broadcasts', _error)
    return NextResponse.json({ message: 'Failed to fetch broadcasts' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const { id: resolvedUserId, role: sessionRole } = await resolveSessionUser(session.user)

  if (!isAdminRole(sessionRole) || !resolvedUserId) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  let payload: unknown

  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ message: 'Invalid JSON payload' }, { status: 400 })
  }

  const parsed = createBroadcastSchema.safeParse(payload)

  if (!parsed.success) {
    return NextResponse.json({
      message: 'Validation failed',
      errors: parsed.error.flatten(),
    }, { status: 422 })
  }

  const data = parsed.data
  const now = new Date()
  const scheduleAt = data.scheduleAt ? new Date(data.scheduleAt) : null
  const expiresAt = data.expiresAt ? new Date(data.expiresAt) : null

  if (scheduleAt && Number.isNaN(scheduleAt.getTime())) {
    return NextResponse.json({ message: 'Invalid schedule date' }, { status: 400 })
  }

  if (expiresAt && Number.isNaN(expiresAt.getTime())) {
    return NextResponse.json({ message: 'Invalid expiry date' }, { status: 400 })
  }

  if (scheduleAt && scheduleAt > now) {
    return NextResponse.json({ message: 'Scheduled broadcasts are not supported yet' }, { status: 400 })
  }

  try {
    let recipientIds: string[] = []

    if (data.audience === 'ALL') {
      const recipients = await prisma.user.findMany({
        where: {
          role: UserRole.STUDENT,
          accountStatus: UserAccountStatus.ACTIVE,
          isActive: true,
        },
        select: { id: true },
      })
      recipientIds = recipients.map((recipient) => recipient.id)
    } else if (data.audience === 'DEPARTMENT') {
      const department = data.audienceFilter && typeof data.audienceFilter === 'object'
        ? (data.audienceFilter as Record<string, unknown>).department
        : undefined

      if (!department || typeof department !== 'string') {
        return NextResponse.json({ message: 'Department filter is required for department broadcasts' }, { status: 400 })
      }

      const recipients = await prisma.user.findMany({
        where: {
          role: UserRole.STUDENT,
          accountStatus: UserAccountStatus.ACTIVE,
          isActive: true,
          department,
        },
        select: { id: true },
      })

      recipientIds = recipients.map((recipient) => recipient.id)
    } else if (data.audience === 'CUSTOM') {
      if (!data.targetUserIds?.length) {
        return NextResponse.json({ message: 'Target user IDs are required for custom broadcasts' }, { status: 400 })
      }
      recipientIds = Array.from(new Set(data.targetUserIds))
    } else if (data.audience === 'ROLE') {
      const role = data.audienceFilter && typeof data.audienceFilter === 'object'
        ? (data.audienceFilter as Record<string, unknown>).role
        : undefined

      if (!role || typeof role !== 'string') {
        return NextResponse.json({ message: 'Role filter is required for role-based broadcasts' }, { status: 400 })
      }

      const normalizedRole = role.toUpperCase() as UserRole
      const allowedRoles = [UserRole.STUDENT, UserRole.ADMIN, UserRole.LIBRARIAN]

      if (!allowedRoles.includes(normalizedRole)) {
        return NextResponse.json({ message: 'Unsupported role filter' }, { status: 400 })
      }

      const recipients = await prisma.user.findMany({
        where: {
          role: normalizedRole,
          accountStatus: UserAccountStatus.ACTIVE,
          isActive: true,
        },
        select: { id: true },
      })

      recipientIds = recipients.map((recipient) => recipient.id)
    }

    if (!recipientIds.length) {
      return NextResponse.json({ message: 'No recipients found for the selected audience' }, { status: 400 })
    }

    const result = await prisma.$transaction(async (tx) => {
      const broadcast = await tx.broadcast.create({
        data: {
          title: data.title.trim(),
          message: data.message.trim(),
          type: data.type,
          priority: data.priority,
          audience: data.audience,
          audienceFilter: (data.audienceFilter ?? null) as AudienceFilterValue,
          targetUserIds: data.audience === 'CUSTOM' ? recipientIds : [],
          deliveredCount: recipientIds.length,
          readCount: 0,
          status: 'SENT',
          isActive: true,
          scheduleAt,
          sentAt: now,
          expiresAt,
          createdById: resolvedUserId,
        },
      })

      await tx.broadcastReceipt.createMany({
        data: recipientIds.map((userId) => ({
          broadcastId: broadcast.id,
          userId,
        })),
      })

      return broadcast
    })

    return NextResponse.json({
      message: 'Broadcast created successfully',
      data: {
        id: result.id,
        title: result.title,
        message: result.message,
        type: result.type,
        priority: result.priority,
        audience: result.audience,
        audienceFilter: result.audienceFilter,
        deliveredCount: result.deliveredCount,
        readCount: result.readCount,
        status: result.status,
        createdAt: result.createdAt.toISOString(),
        sentAt: toIsoString(result.sentAt),
        expiresAt: toIsoString(result.expiresAt),
      },
    }, { status: 201 })
  } catch (error) {
    console.error('Failed to create broadcast', error)
    return NextResponse.json({ message: 'Failed to create broadcast' }, { status: 500 })
  }
}
