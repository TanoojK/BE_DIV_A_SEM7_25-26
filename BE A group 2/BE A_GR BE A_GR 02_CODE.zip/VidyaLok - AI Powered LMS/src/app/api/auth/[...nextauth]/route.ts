import NextAuth from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextResponse } from 'next/server'

type AuthRouteContext = {
  params: {
    nextauth: string[]
  }
}

const nextAuthHandler = NextAuth(authOptions)

// Create NextAuth handler with error handling
const handler = async (req: Request, context: AuthRouteContext) => {
  try {
    return await nextAuthHandler(req, context)
  } catch (error) {
    console.error('NextAuth error:', error)
    return NextResponse.json(
      { error: 'Internal authentication error' },
      { status: 500 }
    )
  }
}

export { handler as GET, handler as POST }
