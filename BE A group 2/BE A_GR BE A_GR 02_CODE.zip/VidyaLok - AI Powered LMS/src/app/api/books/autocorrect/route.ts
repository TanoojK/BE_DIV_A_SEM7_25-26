import { NextRequest, NextResponse } from 'next/server'
import { findBestBookSuggestion } from '@/lib/book-autocorrect'

export async function GET(request: NextRequest) {
  try {
    const query = request.nextUrl.searchParams.get('query') ?? ''

    if (!query.trim()) {
      return NextResponse.json({ success: true, suggestion: null })
    }

    const suggestion = findBestBookSuggestion(query)

    return NextResponse.json({
      success: true,
      suggestion: suggestion?.title ?? null,
      score: suggestion?.score ?? null
    })
  } catch (error) {
    console.error('Autocorrect lookup failed:', error)
    return NextResponse.json(
      {
        success: false,
        suggestion: null,
        error: 'Unable to fetch suggestion'
      },
      { status: 500 }
    )
  }
}
