import { NextRequest, NextResponse } from 'next/server'
import { searchBooks, getBooksAggregations } from '@/lib/books-dataset'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get('query') ?? ''
    const departmentParam = searchParams.get('department') ?? searchParams.get('category') ?? ''
    const publisher = searchParams.get('publisher') ?? ''
    const author = searchParams.get('author') ?? ''
    const pageParam = Number.parseInt(searchParams.get('page') ?? '1', 10)
    const limitParam = Number.parseInt(
      searchParams.get('limit') ?? searchParams.get('pageSize') ?? '50',
      10
    )
    const page = Number.isFinite(pageParam) && pageParam > 0 ? pageParam : 1
    const pageSize = Number.isFinite(limitParam) && limitParam > 0 ? limitParam : undefined

    const result = await searchBooks({
      query,
      department: departmentParam,
      publisher,
      author,
      page,
      pageSize
    })

    const aggregations = await getBooksAggregations()

    return NextResponse.json({
      success: true,
      data: result.items,
      pagination: {
        page: result.page,
        pageSize: result.pageSize,
        total: result.total,
        totalPages: result.totalPages
      },
      stats: result.stats,
      filters: aggregations
    })
  } catch (error) {
    console.error('Error searching books:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to search books' },
      { status: 500 }
    )
  }
}

export async function POST() {
  return NextResponse.json(
    { success: false, error: 'Book catalog is read-only in the current deployment.' },
    { status: 405 }
  )
}

export async function OPTIONS() {
  return NextResponse.json({
    success: true,
    methods: ['GET']
  })
}
