import { NextRequest, NextResponse } from 'next/server'
import { searchBooks } from '@/lib/books-dataset'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get('q') ?? searchParams.get('query') ?? ''
    const limitParam = Number.parseInt(searchParams.get('limit') ?? '20', 10)
    const pageSize = Number.isFinite(limitParam) && limitParam > 0 ? limitParam : 20

    const result = await searchBooks({
      query,
      page: 1,
      pageSize
    })

    return NextResponse.json({
      success: true,
      data: result.items,
      total: result.total,
      stats: result.stats
    })
  } catch (error) {
    console.error('Error searching books:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to search books' },
      { status: 500 }
    )
  }
}
