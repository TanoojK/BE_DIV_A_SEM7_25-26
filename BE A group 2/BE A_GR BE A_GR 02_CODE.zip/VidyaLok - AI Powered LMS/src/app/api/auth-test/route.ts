import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({ status: 'API is working correctly' }, { status: 200 })
}