import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

type FeedbackUpdateData = Parameters<typeof prisma.feedback.update>[0]['data']

type FeedbackRouteContext = {
  params: Promise<{ id: string }>
}

export async function GET(
  request: NextRequest, 
  context: FeedbackRouteContext
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    
    const { id: feedbackId } = await context.params
    
    const feedback = await prisma.feedback.findUnique({
      where: {
        id: feedbackId,
      },
      include: {
        user: {
          select: {
            name: true,
            email: true,
            studentId: true,
          },
        },
      },
    })
    
    if (!feedback) {
      return NextResponse.json(
        { success: false, message: 'Feedback not found' },
        { status: 404 }
      )
    }
    
    // Check if user is authorized to view this feedback
    if (
      session.user.role !== 'ADMIN' &&
      session.user.role !== 'LIBRARIAN' &&
      feedback.userId !== session.user.id
    ) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 403 })
    }
    
    return NextResponse.json({ success: true, feedback })
    
  } catch (error) {
    console.error('Error retrieving feedback:', error)
    return NextResponse.json(
      { success: false, message: 'An error occurred while retrieving feedback' },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: NextRequest, 
  context: FeedbackRouteContext
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user || (session.user.role !== 'ADMIN' && session.user.role !== 'LIBRARIAN')) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    
    const { id: feedbackId } = await context.params
    const body = await request.json()

    const rawStatus = typeof body?.status === 'string' ? body.status.trim() : ''
    const rawResponse = typeof body?.response === 'string' ? body.response.trim() : ''

    if (!rawStatus && !rawResponse) {
      return NextResponse.json(
        { success: false, message: 'No update data provided' },
        { status: 400 }
      )
    }
    
    // Check if feedback exists
    const existingFeedback = await prisma.feedback.findUnique({
      where: { id: feedbackId },
    })
    
    if (!existingFeedback) {
      return NextResponse.json(
        { success: false, message: 'Feedback not found' },
        { status: 404 }
      )
    }
    
    type FeedbackStatusValue = typeof existingFeedback.status
    const normalizeStatus = (value: string): FeedbackStatusValue | undefined => {
      const upperValueRaw = value.toUpperCase()
      const allowedStatuses = ['PENDING', 'IN_PROGRESS', 'UNDER_REVIEW', 'RESOLVED', 'CLOSED'] as const

      if (upperValueRaw === 'ACKNOWLEDGED') {
        return 'IN_PROGRESS'
      }

      if (upperValueRaw === 'OPEN') {
        return 'PENDING'
      }

      type AllowedStatus = typeof allowedStatuses[number]

      if (allowedStatuses.includes(upperValueRaw as AllowedStatus)) {
        return upperValueRaw as FeedbackStatusValue
      }

      return undefined
    }

    const nextStatus = normalizeStatus(rawStatus)
    const hasResponse = rawResponse.length > 0

    if (!hasResponse && !nextStatus) {
      return NextResponse.json(
        { success: false, message: 'Invalid status value' },
        { status: 400 }
      )
    }

    const updateData: Record<string, unknown> = {}

    if (hasResponse) {
      updateData.response = rawResponse
      updateData.status = 'RESOLVED'
      updateData.resolvedAt = new Date()
    } else if (nextStatus) {
      updateData.status = nextStatus
      if (nextStatus === 'RESOLVED' || nextStatus === 'CLOSED') {
        updateData.resolvedAt = new Date()
      } else {
        updateData.resolvedAt = null
      }
    }

    const updatedFeedback = await prisma.feedback.update({
      where: { id: feedbackId },
      data: updateData as FeedbackUpdateData,
    })
    
    return NextResponse.json({ success: true, feedback: updatedFeedback })
    
  } catch (error) {
    console.error('Error updating feedback:', error)
    return NextResponse.json(
      { success: false, message: 'An error occurred while updating feedback' },
      { status: 500 }
    )
  }
}