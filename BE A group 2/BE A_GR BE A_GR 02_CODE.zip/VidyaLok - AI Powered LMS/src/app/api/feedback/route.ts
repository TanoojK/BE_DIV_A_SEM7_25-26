import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { PrismaClientValidationError } from '@prisma/client/runtime/library'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

type FeedbackCreateData = Parameters<typeof prisma.feedback.create>[0]['data']

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user || session.user.role !== 'STUDENT') {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    
    // Parse request body
    const body = await request.json()
    const { feedbackType, subject, message } = body
    const rawRating = body?.rating
    const normalizedRating = typeof rawRating === 'number' && Number.isFinite(rawRating)
      ? Math.min(5, Math.max(0, Math.round(rawRating)))
      : undefined
    
    // Validate required fields
    if (!feedbackType || !subject || !message) {
      return NextResponse.json(
        { success: false, message: 'Missing required fields' },
        { status: 400 }
      )
    }
    
    // Create feedback in database
    const baseData: FeedbackCreateData = {
      type: feedbackType,
      subject,
      message,
      status: 'PENDING',
      user: {
        connect: { id: session.user.id },
      },
    }

    const createData: FeedbackCreateData =
      typeof normalizedRating === 'number'
        ? { ...baseData, rating: normalizedRating }
        : baseData

    let feedback

    try {
      feedback = await prisma.feedback.create({
        data: createData,
      })
    } catch (error) {
      if (
        typeof normalizedRating === 'number' &&
        error instanceof PrismaClientValidationError
      ) {
        feedback = await prisma.feedback.create({ data: baseData })
      } else {
        throw error
      }
    }
    
    return NextResponse.json(
      { 
        success: true, 
        message: 'Feedback submitted successfully', 
        feedback: {
          id: feedback.id,
          createdAt: feedback.createdAt,
          rating: (feedback as { rating?: number }).rating ?? normalizedRating ?? 0
        }
      },
      { status: 201 }
    )
    
  } catch (error) {
    console.error('Error submitting feedback:', error)
    return NextResponse.json(
      { success: false, message: 'An error occurred while submitting your feedback' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    
    const userId = session.user.id
    
    // If student, return only their feedback
    if (session.user.role === 'STUDENT') {
      const feedbackItems = await prisma.feedback.findMany({
        where: {
          userId: userId,
        },
        orderBy: {
          createdAt: 'desc',
        },
        include: {
          user: {
            select: {
              name: true,
              email: true,
              studentId: true,
                branch: true,
              department: true,
              yearOfStudy: true,
            },
          },
        },
      })
      return NextResponse.json({ success: true, feedback: feedbackItems })
    }
    
    // If admin or librarian, return all feedback with pagination
    if (session.user.role === 'ADMIN' || session.user.role === 'LIBRARIAN') {
      const searchParams = request.nextUrl.searchParams
      const page = parseInt(searchParams.get('page') || '1')
      const limit = parseInt(searchParams.get('limit') || '10')
      const skip = (page - 1) * limit
      
      const [feedbackItems, total] = await Promise.all([
        prisma.feedback.findMany({
          skip,
          take: limit,
          orderBy: {
            createdAt: 'desc',
          },
          include: {
            user: {
              select: {
                name: true,
                email: true,
                studentId: true,
                branch: true,
                department: true,
                yearOfStudy: true,
              },
            },
          },
        }),
        prisma.feedback.count(),
      ])

      return NextResponse.json({ 
        success: true, 
        feedback: feedbackItems,
        pagination: {
          total,
          page,
          limit,
          pages: Math.ceil(total / limit)
        }
      })
    }
    
    return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    
  } catch (error) {
    console.error('Error retrieving feedback:', error)
    return NextResponse.json(
      { success: false, message: 'An error occurred while retrieving feedback' },
      { status: 500 }
    )
  }
}