import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'

import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

const MAX_INTERESTS = 12
const MAX_INTEREST_LENGTH = 64

const sanitizeInterest = (value: string) =>
  value
    .trim()
    .replace(/\s+/g, ' ')

const normalizeInterests = (candidate: unknown) => {
  if (!Array.isArray(candidate)) {
    throw new Error('Interests must be an array of strings')
  }

  const cleaned: string[] = []
  const seen = new Set<string>()

  for (const item of candidate) {
    if (typeof item !== 'string') {
      throw new Error('Each interest must be a string')
    }

    const normalized = sanitizeInterest(item)

    if (!normalized) {
      continue
    }

    if (normalized.length > MAX_INTEREST_LENGTH) {
      throw new Error(`Interest "${normalized.slice(0, 32)}…" is too long`)
    }

    const key = normalized.toLowerCase()
    if (!seen.has(key)) {
      seen.add(key)
      cleaned.push(normalized)
    }
  }

  if (cleaned.length > MAX_INTERESTS) {
    throw new Error(`You can select up to ${MAX_INTERESTS} interests`)
  }

  return cleaned
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const payload = await request.json()
    const interests = normalizeInterests(payload?.interests ?? [])

    await prisma.user.update({
      where: { id: session.user.id },
      data: { interests },
    })

    return NextResponse.json({ success: true, data: { interests } })
  } catch (error) {
    console.error('Failed to update interests', error)

    if (error instanceof Error) {
      return NextResponse.json({ success: false, error: error.message }, { status: 400 })
    }

    return NextResponse.json({ success: false, error: 'Unable to update interests' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { interests: true },
    })

    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 })
    }

    return NextResponse.json({ success: true, data: { interests: user.interests ?? [] } })
  } catch (error) {
    console.error('Failed to load interests', error)
    return NextResponse.json({ success: false, error: 'Unable to load interests' }, { status: 500 })
  }
}