import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { UserRole, BookRequestStatus } from '@/types'

const ALLOWED_PRIORITIES = new Set(['low', 'medium', 'high'])

type BookRequestUpdateData = Parameters<typeof prisma.bookRequest.update>[0]['data']

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  if (session.user.role !== UserRole.ADMIN && session.user.role !== UserRole.LIBRARIAN) {
    return NextResponse.json({ message: 'Only administrators can update requests' }, { status: 403 })
  }

  const requestId = params.id

  if (!requestId || typeof requestId !== 'string') {
    return NextResponse.json({ message: 'Request ID is required' }, { status: 400 })
  }

  try {
    const body = await request.json()
    const { status, adminNotes, priority } = body ?? {}

    if (!status && adminNotes === undefined && !priority) {
      return NextResponse.json({ message: 'No update fields provided' }, { status: 400 })
    }

  const updateData: BookRequestUpdateData = {}

    if (status) {
      const normalizedStatus = String(status).toUpperCase()
      if (!(normalizedStatus in BookRequestStatus)) {
        return NextResponse.json({ message: 'Invalid status' }, { status: 400 })
      }
  updateData.status = normalizedStatus as BookRequestStatus
      updateData.respondedAt = new Date()
    }

    if (priority) {
      const normalizedPriority = String(priority).toLowerCase()
      if (!ALLOWED_PRIORITIES.has(normalizedPriority)) {
        return NextResponse.json({ message: 'Invalid priority' }, { status: 400 })
      }
  updateData.priority = normalizedPriority
    }

    if (adminNotes !== undefined) {
      if (adminNotes !== null && typeof adminNotes !== 'string') {
        return NextResponse.json({ message: 'Invalid admin notes' }, { status: 400 })
      }
  updateData.adminNotes = adminNotes ?? null
    }

    const updatedRequest = await prisma.bookRequest.update({
      where: { id: requestId },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            studentId: true,
            branch: true,
            department: true,
          },
        },
      },
    })

    return NextResponse.json({ data: updatedRequest })
  } catch (error) {
    console.error('[BOOK_REQUEST_PATCH]', error)

    if (error instanceof PrismaClientKnownRequestError && error.code === 'P2025') {
      return NextResponse.json({ message: 'Request not found' }, { status: 404 })
    }

    return NextResponse.json({ message: 'Failed to update request' }, { status: 500 })
  }
}
