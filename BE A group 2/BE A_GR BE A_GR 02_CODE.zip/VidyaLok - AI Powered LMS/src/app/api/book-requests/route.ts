import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import type { Prisma } from '@prisma/client'

import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { UserRole, BookRequestStatus } from '@/types'

type BookRequestWhereInput = Prisma.BookRequestWhereInput

const ALLOWED_REQUEST_TYPES = new Set([
  'book_request',
  'book_renewal',
  'library_service',
  'research_access',
  'study_room',
  'other',
])

const ALLOWED_PRIORITIES = new Set(['low', 'medium', 'high'])

export async function GET(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const url = new URL(request.url)
  const status = url.searchParams.get('status')
  const search = url.searchParams.get('q') ?? ''

  const normalizedStatus = status?.toUpperCase()
  const statusFilter = normalizedStatus && Object.prototype.hasOwnProperty.call(BookRequestStatus, normalizedStatus)
    ? (BookRequestStatus as Record<string, BookRequestStatus>)[normalizedStatus]
    : undefined

  try {
    const where: BookRequestWhereInput = {}

    if (session.user.role === UserRole.STUDENT) {
      where.userId = session.user.id
    }

    if (statusFilter) {
      where.status = statusFilter
    }

    if (search) {
      where.OR = [
        { bookTitle: { contains: search, mode: 'insensitive' } },
        { author: { contains: search, mode: 'insensitive' } },
        { isbn: { contains: search, mode: 'insensitive' } },
        { reason: { contains: search, mode: 'insensitive' } },
      ]
    }

    const requests = await prisma.bookRequest.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            studentId: true,
            branch: true,
            department: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ data: requests })
  } catch (error) {
    console.error('[BOOK_REQUESTS_GET]', error)
    return NextResponse.json({ message: 'Failed to load requests' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  if (session.user.role !== UserRole.STUDENT) {
    return NextResponse.json({ message: 'Only students can create requests' }, { status: 403 })
  }

  try {
    const body = await request.json()
    const {
      type,
      title,
      author,
      isbn,
      publisher,
      edition,
      reason,
      priority,
      description,
    } = body ?? {}

    if (!title || typeof title !== 'string') {
      return NextResponse.json({ message: 'Title is required' }, { status: 400 })
    }

    if (!reason || typeof reason !== 'string') {
      return NextResponse.json({ message: 'Reason is required' }, { status: 400 })
    }

    if (author && typeof author !== 'string') {
      return NextResponse.json({ message: 'Invalid author' }, { status: 400 })
    }

    if (isbn && typeof isbn !== 'string') {
      return NextResponse.json({ message: 'Invalid ISBN' }, { status: 400 })
    }

    if (publisher && typeof publisher !== 'string') {
      return NextResponse.json({ message: 'Invalid publisher' }, { status: 400 })
    }

    if (edition && typeof edition !== 'string') {
      return NextResponse.json({ message: 'Invalid edition' }, { status: 400 })
    }

    if (description && typeof description !== 'string') {
      return NextResponse.json({ message: 'Invalid description' }, { status: 400 })
    }

    const sanitizedType = typeof type === 'string' && ALLOWED_REQUEST_TYPES.has(type) ? type : 'book_request'
    const sanitizedPriority = typeof priority === 'string' && ALLOWED_PRIORITIES.has(priority) ? priority : 'medium'

    const newRequest = await prisma.bookRequest.create({
      data: {
    userId: session.user.id,
    requestType: sanitizedType,
    bookTitle: title,
    author: author ?? null,
    isbn: isbn ?? null,
        reason,
        priority: sanitizedPriority,
        publisher: publisher ?? null,
        edition: edition ?? null,
        description: description ?? null,
        status: BookRequestStatus.PENDING,
      },
    })

    return NextResponse.json({ data: newRequest }, { status: 201 })
  } catch (error) {
    console.error('[BOOK_REQUESTS_POST]', error)
    return NextResponse.json({ message: 'Failed to submit request' }, { status: 500 })
  }
}
