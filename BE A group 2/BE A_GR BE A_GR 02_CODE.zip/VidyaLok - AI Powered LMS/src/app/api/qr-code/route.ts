import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createSignedQRToken, isTokenExpiringSoon } from '@/lib/qr-utils'

const RECENT_LIMIT = 10

async function buildStudentQrResponse(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      studentId: true,
      name: true,
      email: true,
      phone: true,
      branch: true,
      department: true,
      yearOfStudy: true,
      semester: true,
      createdAt: true,
    },
  })

  if (!user) {
    return null
  }

  const { token, payload } = createSignedQRToken(user.studentId, user.name, user.department ?? user.branch ?? null)

  const recentEntries = await prisma.entryLog.findMany({
    where: { userId: user.id },
    orderBy: { entryTime: 'desc' },
    take: RECENT_LIMIT,
  })

  type EntryLogRecord = (typeof recentEntries)[number]

  const latestEntry = recentEntries.length ? recentEntries[0] : null
  const openEntry = recentEntries.find((entry: EntryLogRecord) => entry.exitTime === null)
  const status = {
    currentlyInside: Boolean(openEntry),
    lastVisit: latestEntry
      ? {
          entryTime: latestEntry.entryTime,
          exitTime: latestEntry.exitTime,
          durationMinutes: latestEntry.duration ?? null,
        }
      : null,
    expiringSoon: isTokenExpiringSoon(payload),
  }

  return {
    token,
    issuedAt: payload.issuedAt,
    expiresAt: payload.expiresAt,
    ttlMinutes: Math.round((payload.expiresAt - payload.issuedAt) / 60000),
    student: {
      id: user.id,
      name: user.name,
      studentId: user.studentId,
      email: user.email,
      phone: user.phone,
      branch: user.branch,
      department: user.department,
      yearOfStudy: user.yearOfStudy,
      semester: user.semester,
      joinedAt: user.createdAt,
    },
    status,
    recentEntries: recentEntries.map((entry: EntryLogRecord) => ({
      id: entry.id,
      entryTime: entry.entryTime,
      exitTime: entry.exitTime,
      durationMinutes: entry.duration,
      currentlyInside: entry.exitTime === null,
    })),
  }
}

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  if (session.user.role !== 'STUDENT') {
    return NextResponse.json({ message: 'QR codes are only available to student accounts' }, { status: 403 })
  }

  const response = await buildStudentQrResponse(session.user.id)

  if (!response) {
    return NextResponse.json({ message: 'Student record not found' }, { status: 404 })
  }

  return NextResponse.json(response)
}

export async function POST() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  if (session.user.role !== 'STUDENT') {
    return NextResponse.json({ message: 'QR codes are only available to student accounts' }, { status: 403 })
  }

  const response = await buildStudentQrResponse(session.user.id)

  if (!response) {
    return NextResponse.json({ message: 'Student record not found' }, { status: 404 })
  }

  return NextResponse.json(response)
}
