import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { verifySignedQRToken } from '@/lib/qr-utils'

const ADMIN_ROLES = new Set(['ADMIN', 'LIBRARIAN'])

type EntryLogUpdateData = Parameters<typeof prisma.entryLog.update>[0]['data']
type EntryLogCreateData = Parameters<typeof prisma.entryLog.create>[0]['data']

const getStartOfDay = () => {
  const date = new Date()
  date.setHours(0, 0, 0, 0)
  return date
}

async function buildEntrySummary() {
  const [todaysEntries, studentsInside, recentEntriesRaw] = await Promise.all([
    prisma.entryLog.count({
      where: {
        entryTime: { gte: getStartOfDay() },
      },
    }),
    prisma.entryLog.count({ where: { exitTime: null } }),
    prisma.entryLog.findMany({
      orderBy: { entryTime: 'desc' },
      take: 15,
      include: {
        user: {
          select: {
            studentId: true,
            name: true,
            department: true,
          },
        },
      },
    }),
  ])

  type RecentEntry = (typeof recentEntriesRaw)[number]

  return {
    stats: {
      studentsInside,
      todaysEntries,
    },
    recentEntries: recentEntriesRaw.map((entry: RecentEntry) => ({
      id: entry.id,
      entryTime: entry.entryTime,
      exitTime: entry.exitTime,
      durationMinutes: entry.duration,
      entryPoint: entry.entryPoint ?? null,
      entryMethod: entry.entryMethod ?? null,
      studentId: entry.user.studentId,
      studentName: entry.user.name,
      department: entry.user.department,
    })),
  }
}

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session?.user || !ADMIN_ROLES.has(session.user.role)) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const summary = await buildEntrySummary()
  return NextResponse.json({ success: true, ...summary })
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session?.user || !ADMIN_ROLES.has(session.user.role)) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
  }

  const body = await request.json().catch(() => null)

  if (!body || (typeof body !== 'object')) {
    return NextResponse.json({ message: 'Invalid request body' }, { status: 400 })
  }

  const { token, studentId: manualStudentId, entryPoint, notes } = body as {
    token?: string
    studentId?: string
    entryPoint?: string
    notes?: string
  }

  if (!token && !manualStudentId) {
    return NextResponse.json({ message: 'Provide either a QR token or a studentId for manual entry' }, { status: 400 })
  }

  let verifiedStudentId: string | null = null
  let tokenPayload: { studentId: string; studentName: string } | null = null
  let method: 'qr_code' | 'manual' = 'manual'

  if (token) {
    try {
      const payload = verifySignedQRToken(token)
      verifiedStudentId = payload.studentId
      tokenPayload = { studentId: payload.studentId, studentName: payload.studentName }
      method = 'qr_code'
    } catch (error) {
      return NextResponse.json({ message: error instanceof Error ? error.message : 'Invalid QR token' }, { status: 400 })
    }
  }

  const studentId = verifiedStudentId
    ? verifiedStudentId.trim()
    : (manualStudentId ?? '').trim().toUpperCase()

  if (!studentId) {
    return NextResponse.json({ message: 'Student ID is required' }, { status: 400 })
  }

  const student = await prisma.user.findFirst({
    where: { studentId, role: 'STUDENT' },
    select: {
      id: true,
      studentId: true,
      name: true,
      email: true,
      branch: true,
      department: true,
      yearOfStudy: true,
      semester: true,
      isActive: true,
    },
  })

  if (!student || !student.isActive) {
    return NextResponse.json({ message: 'Student account not found or inactive' }, { status: 404 })
  }

  if (tokenPayload && tokenPayload.studentName !== student.name) {
    // Ensure QR token matches actual student record to prevent reuse attacks
    return NextResponse.json({ message: 'QR token mismatch for student record' }, { status: 409 })
  }

  const now = new Date()
  const location = entryPoint?.trim() || 'Main Entrance'

  const recentLogs = await prisma.entryLog.findMany({
    where: { userId: student.id },
    orderBy: { entryTime: 'desc' },
    take: 10,
  })

  type RecentLog = (typeof recentLogs)[number]

  const openLog = recentLogs.find((log: RecentLog) => !log.exitTime) ?? null

  let entryType: 'ENTRY' | 'EXIT'
  let updatedLog: {
    id: string
    entryTime: Date
    exitTime: Date | null
    duration: number | null
    entryPoint: string | null
    entryMethod: string | null
  }

  if (openLog) {
    entryType = 'EXIT'
    const durationMinutes = Math.max(1, Math.round((now.getTime() - openLog.entryTime.getTime()) / 60000))
    const existingEntryPoint = (openLog as typeof openLog & { entryPoint?: string | null }).entryPoint ?? null
    const existingMethod = (openLog as typeof openLog & { entryMethod?: string | null }).entryMethod ?? null
    const resolvedEntryPoint = existingEntryPoint ?? location ?? null
    const resolvedEntryMethod = existingMethod ?? method ?? null
    const updateData = {
      exitTime: now,
      duration: durationMinutes,
      entryPoint: resolvedEntryPoint,
      entryMethod: resolvedEntryMethod,
      recordedBy: session.user.id,
      notes,
    } as EntryLogUpdateData

    await prisma.entryLog.update({
      where: { id: openLog.id },
      data: updateData,
    })
    updatedLog = {
      id: openLog.id,
      entryTime: openLog.entryTime,
      exitTime: now,
      duration: durationMinutes,
      entryPoint: resolvedEntryPoint,
      entryMethod: resolvedEntryMethod,
    }
  } else {
    entryType = 'ENTRY'
    const createData = {
      userId: student.id,
      entryTime: now,
      exitTime: null,
      duration: null,
      entryPoint: location,
      entryMethod: method,
      recordedBy: session.user.id,
      notes,
    } as EntryLogCreateData
    const log = await prisma.entryLog.create({
      data: createData,
    })
    updatedLog = {
      id: log.id,
      entryTime: log.entryTime,
      exitTime: log.exitTime,
      duration: log.duration,
      entryPoint: location,
      entryMethod: method,
    }
  }

  if (openLog) {
    const staleOpenLogs = recentLogs.filter((log: RecentLog) => !log.exitTime && log.id !== openLog.id)
    if (staleOpenLogs.length) {
      await Promise.all(
        staleOpenLogs.map((log: RecentLog) => {
          const durationMinutes = Math.max(1, Math.round((now.getTime() - log.entryTime.getTime()) / 60000))
          const logEntryPoint = (log as typeof log & { entryPoint?: string | null }).entryPoint ?? location
          const logMethod = (log as typeof log & { entryMethod?: string | null }).entryMethod ?? method
          const existingNotes = (log as typeof log & { notes?: string | null }).notes ?? null
          const combinedNotes = existingNotes ? existingNotes : 'Auto-closed duplicate open session'

          return prisma.entryLog.update({
            where: { id: log.id },
            data: {
              exitTime: now,
              duration: durationMinutes,
              entryPoint: logEntryPoint,
              entryMethod: logMethod,
              recordedBy: session.user.id,
              notes: combinedNotes,
            } as EntryLogUpdateData,
          })
        })
      )
    }
  }

  const summary = await buildEntrySummary()

  return NextResponse.json({
    success: true,
    entryType,
    log: updatedLog,
    student: {
      studentId: student.studentId,
      name: student.name,
      email: student.email,
      branch: student.branch,
      department: student.department,
      yearOfStudy: student.yearOfStudy,
      semester: student.semester,
    },
    ...summary,
  })
}
