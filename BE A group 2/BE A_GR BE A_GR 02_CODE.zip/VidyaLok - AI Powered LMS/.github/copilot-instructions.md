# VidyaLok - AI Powered Smart Library Management System

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization -->

## Project Overview
VidyaLok is an AI-Powered Smart Library Ecosystem Management system built with Next.js, TypeScript, and Tailwind CSS. The system provides comprehensive library management features for both students and administrators.

## Architecture Guidelines
- Use Next.js App Router with TypeScript
- Implement modular components for each feature
- Use Tailwind CSS for styling with professional design
- Create separate API routes for different functionalities
- Follow clean code principles and proper error handling
- Use proper TypeScript types for all data structures

## Key Features to Implement
### Student Features:
- Student ID-Based Entry System
- Smart Book Search & Borrow System
- Borrowing History & Due Reminders
- Live Seat Availability Indicator
- Library Chatbot
- Feedback/Complaint System

### Admin Features:
- Book Inventory Management
- Real-Time Entry/Exit Logs
- Analytics Dashboard
- Borrow & Return Management
- Overdue Alerts & Fine Reports
- Usage Report Generator
- Emergency Broadcast System

## Code Standards
- Use descriptive component and function names
- Implement proper error boundaries
- Add loading states for async operations
- Use consistent naming conventions
- Add proper JSDoc comments for complex functions
- Implement responsive design for all components

## Database Considerations
- Design schemas for books, students, transactions, logs
- Implement proper relationships between entities
- Use appropriate indexing for performance
- Handle data validation on both client and server side
